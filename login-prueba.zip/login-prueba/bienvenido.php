<!DOCTYPE html>
<html>
<head>
	<title>Inicio</title>
	<?php require_once "scripts.php"; ?>
</head>
<body>
<br><br><br>
	<div class="container">
		<div class="row">
			<div class="col-sm-12">
				<div class="jumbotron">
				<a href="php/salir.php" class="btn btn-info">Cerrar sesión</a>
					<h2>Bienvenido</h2>
				</div>
			</div>
		</div>
	</div>
</body>
</html>